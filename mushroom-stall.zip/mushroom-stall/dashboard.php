<?php
include 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}


$user_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role = 'user'"))['total'];
$order_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders"))['total'];
$review_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM reviews"))['total'];
?>

<h2 class="mb-4">Admin Dashboard</h2>

<div class="row">
  <div class="col-md-4 mb-4">
    <div class="card bg-primary text-white h-100 shadow-sm">
      <div class="card-body">
        <h5 class="card-title">User Management</h5>
        <p class="card-text">Total Users: <strong><?= $user_count ?></strong></p>
        <a href="manage_users.php" class="btn btn-light">View Users</a>
      </div>
    </div>
  </div>
  <div class="col-md-4 mb-4">
    <div class="card bg-success text-white h-100 shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Food Management</h5>
        <p class="card-text">Manage mushroom products</p>
        <a href="manage_food.php" class="btn btn-light">Manage Products</a>
      </div>
    </div>
  </div>
  <div class="col-md-4 mb-4">
    <div class="card bg-info text-white h-100 shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Order Summary</h5>
        <p class="card-text">Total Orders: <strong><?= $order_count ?></strong></p>
        <a href="manage_orders.php" class="btn btn-light">Manage Orders</a>
      </div>
    </div>
  </div>
  <div class="col-md-4 mb-4">
    <div class="card bg-info text-white h-100 shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Order Summary</h5>
        <p class="card-text">Total Reviews: <strong><?= $review_count ?></strong></p>
        <a href="manage_reviews.php" class="btn btn-secondary">Manage Reviews</a>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
