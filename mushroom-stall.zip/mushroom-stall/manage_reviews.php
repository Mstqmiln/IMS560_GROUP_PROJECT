<?php
include 'db.php';
include 'header.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$res = mysqli_query($conn, "
  SELECT r.*, u.name AS user_name, p.name AS product_name 
  FROM reviews r
  JOIN users u ON r.user_id = u.id
  JOIN products p ON r.product_id = p.id
  ORDER BY r.created_at DESC
");
?>

<h4>Manage Reviews</h4>

<table class="table table-bordered">
  <thead class="table-dark">
    <tr>
      <th>#</th>
      <th>User</th>
      <th>Product</th>
      <th>Comment</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <?php $i = 1; while ($row = mysqli_fetch_assoc($res)): ?>
    <tr>
      <td><?= $i++ ?></td>
      <td><?= htmlspecialchars($row['user_name']) ?></td>
      <td><?= htmlspecialchars($row['product_name']) ?></td>
      <td><?= htmlspecialchars($row['comment']) ?></td>
      <td><?= $row['created_at'] ?></td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>

<?php include 'footer.php'; ?>
