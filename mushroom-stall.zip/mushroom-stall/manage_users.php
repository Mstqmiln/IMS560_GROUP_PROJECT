<?php
include 'db.php';
include 'header.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Edit
$editing = false;
if (isset($_GET['edit'])) {
    $editing = true;
    $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = " . $_GET['edit']));
}

// Update
if (isset($_POST['update_user'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    mysqli_query($conn, "UPDATE users SET name = '$name' WHERE id = $id");
    header("Location: manage_users.php");
    exit();
}

// Delete
if (isset($_GET['delete'])) {
    mysqli_query($conn, "DELETE FROM users WHERE id = " . $_GET['delete']);
    header("Location: manage_users.php");
    exit();
}
?>

<h4><?= $editing ? "Edit User" : "User List" ?></h4>

<?php if ($editing): ?>
<form method="POST" class="mb-3">
  <input type="hidden" name="id" value="<?= $user['id'] ?>">
  <input type="text" name="name" value="<?= $user['name'] ?>" class="form-control mb-2" required>
  <button type="submit" name="update_user" class="btn btn-warning">Update</button>
  <a href="manage_users.php" class="btn btn-secondary">Cancel</a>
</form>
<?php endif; ?>

<table class="table table-bordered">
  <tr>
    <th>#</th><th>Name</th><th>Email</th><th>Actions</th>
  </tr>
  <?php
  $i = 1;
  $res = mysqli_query($conn, "SELECT * FROM users WHERE role = 'user'");
  while ($row = mysqli_fetch_assoc($res)):
  ?>
  <tr>
    <td><?= $i++ ?></td>
    <td><?= $row['name'] ?></td>
    <td><?= $row['email'] ?></td>
    <td>
      <a href="manage_users.php?edit=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
      <a href="manage_users.php?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this user?')">Delete</a>
    </td>
  </tr>
  <?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
