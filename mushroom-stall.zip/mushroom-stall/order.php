<?php
include 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['product_id'])) {
    echo "<div class='alert alert-danger'>No product selected.</div>";
    include 'footer.php';
    exit();
}

$product_id = (int)$_GET['product_id'];

// Get product details
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    echo "<div class='alert alert-danger'>Product not found.</div>";
    include 'footer.php';
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quantity = (int)$_POST['quantity'];
    if ($quantity > 0) {
        $user_id = $_SESSION['user_id'];
        $price = $product['price'];
        $total_price = $price * $quantity;

        // Step 1: Insert into `orders` table
        $stmt = $conn->prepare("INSERT INTO orders (user_id, quantity, total_price) VALUES (?, ?, ?)");
        $stmt->bind_param("iid", $user_id, $quantity, $total_price);
        $stmt->execute();
        $order_id = $stmt->insert_id;
        $stmt->close();

        // Step 2: Insert into `order_items` table
        $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiid", $order_id, $product_id, $quantity, $price);
        $stmt->execute();
        $stmt->close();

        echo "<div class='alert alert-success'>Order placed successfully! <a href='order_history.php'>View Order History</a></div>";
    } else {
        echo "<div class='alert alert-danger'>Quantity must be at least 1.</div>";
    }
}
?>

<h2 class="mb-4">Order Mushroom</h2>

<div class="card mb-4 shadow-sm">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="images/<?= htmlspecialchars($product['image']) ?>" class="img-fluid rounded-start" alt="<?= htmlspecialchars($product['name']) ?>">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
        <p class="card-text"><?= htmlspecialchars($product['description']) ?></p>
        <p class="text-primary fw-bold">Price: RM <?= number_format($product['price'], 2) ?></p>

        <form method="POST">
          <div class="mb-3">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" name="quantity" id="quantity" class="form-control" min="1" value="1" required>
          </div>
          <button type="submit" class="btn btn-success">Confirm Order</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
