<?php
include 'db.php';
include 'header.php';

if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Update status
if (isset($_POST['update_status'])) {
    $id = $_POST['order_id'];
    $status = $_POST['status'];
    mysqli_query($conn, "UPDATE orders SET status = '$status' WHERE id = $id");
    header("Location: manage_orders.php");
    exit();
}

// Get order data with multiple items
$res = mysqli_query($conn, "
  SELECT o.*, u.name AS user_name, 
         GROUP_CONCAT(CONCAT(p.name, ' (x', oi.quantity, ')') SEPARATOR '<br>') AS items,
         SUM(oi.quantity) AS total_items
  FROM orders o
  JOIN users u ON o.user_id = u.id
  JOIN order_items oi ON o.id = oi.order_id
  JOIN products p ON oi.product_id = p.id
  GROUP BY o.id
  ORDER BY o.created_at DESC
");
?>

<h4>Manage Orders</h4>
<table class="table table-bordered">
  <tr>
    <th>#</th>
    <th>User</th>
    <th>Items</th>
    <th>Total Qty</th>
    <th>Total Price</th>
    <th>Status</th>
    <th>Actions</th>
  </tr>
  <?php $i = 1; while ($row = mysqli_fetch_assoc($res)): ?>
  <tr>
    <td><?= $i++ ?></td>
    <td><?= htmlspecialchars($row['user_name']) ?></td>
    <td><?= $row['items'] ?></td>
    <td><?= $row['total_items'] ?></td>
    <td>RM <?= number_format($row['total_price'], 2) ?></td>
    <td><?= ucfirst($row['status']) ?></td>
    <td>
      <form method="POST" class="d-flex gap-1">
        <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
        <select name="status" class="form-select form-select-sm">
          <option value="pending" <?= $row['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
          <option value="success" <?= $row['status'] == 'success' ? 'selected' : '' ?>>Success</option>
        </select>
        <button type="submit" name="update_status" class="btn btn-sm btn-primary">Update</button>
      </form>
    </td>
  </tr>
  <?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
