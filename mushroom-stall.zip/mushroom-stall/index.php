<?php include 'header.php'; ?>

<div class="text-center">
    <h1 class="mb-4">Welcome to the Mushroomie 🍄</h1>
    <p class="lead">Buy fresh mushrooms online. Check reviews, place orders, and track your history.</p>

    <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="btn btn-primary btn-lg mt-3">Get Started</a>
    <?php else: ?>
        <?php if ($_SESSION['role'] == 'admin'): ?>
            <a href="dashboard.php" class="btn btn-success btn-lg mt-3">Go to Admin Dashboard</a>
        <?php else: ?>
            <a href="products.php" class="btn btn-success btn-lg mt-3">Browse Mushrooms</a>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>