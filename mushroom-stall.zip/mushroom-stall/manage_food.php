<?php
include 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM products WHERE id = $id");
    header("Location: manage_food.php");
    exit();
}

// Handle Edit View
$editing = false;
$edit_data = [];
if (isset($_GET['edit'])) {
    $editing = true;
    $edit_id = (int)$_GET['edit'];
    $edit_result = mysqli_query($conn, "SELECT * FROM products WHERE id = $edit_id");
    if ($edit_result) {
        $edit_data = mysqli_fetch_assoc($edit_result);
    }
}

// Handle Add
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];
    $img = $_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], "images/$img");
    mysqli_query($conn, "INSERT INTO products (name, description, price, image) VALUES ('$name', '$desc', '$price', '$img')");
    header("Location: manage_food.php");
    exit();
}

// Handle Update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    if (!empty($_FILES['image']['name'])) {
        $img = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "images/$img");
        mysqli_query($conn, "UPDATE products SET name='$name', description='$desc', price='$price', image='$img' WHERE id=$id");
    } else {
        mysqli_query($conn, "UPDATE products SET name='$name', description='$desc', price='$price' WHERE id=$id");
    }

    header("Location: manage_food.php");
    exit();
}
?>

<div class="card mb-4">
  <div class="card-body">
    <h4><?= $editing ? "Edit Product" : "Add Product" ?></h4>
    <form method="POST" enctype="multipart/form-data">
      <?php if ($editing): ?>
        <input type="hidden" name="id" value="<?= $edit_data['id'] ?>">
      <?php endif; ?>
      <input type="text" name="name" placeholder="Name" class="form-control mb-2" value="<?= $editing ? $edit_data['name'] : '' ?>" required>
      <textarea name="description" class="form-control mb-2" placeholder="Description" required><?= $editing ? $edit_data['description'] : '' ?></textarea>
      <input type="number" name="price" placeholder="Price" step="0.01" class="form-control mb-2" value="<?= $editing ? $edit_data['price'] : '' ?>" required>
      <input type="file" name="image" class="form-control mb-2" <?= $editing ? '' : 'required' ?>>
      <?php if ($editing && $edit_data['image']): ?>
        <img src="images/<?= $edit_data['image'] ?>" width="100" class="mb-2">
      <?php endif; ?>
      <button type="submit" name="<?= $editing ? 'update' : 'add' ?>" class="btn btn-<?= $editing ? 'warning' : 'success' ?>">
        <?= $editing ? 'Update' : 'Add' ?>
      </button>
      <?php if ($editing): ?>
        <a href="manage_food.php" class="btn btn-secondary ms-2">Cancel</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<h4>Product List</h4>
<table class="table table-bordered">
  <tr>
    <th>#</th><th>Image</th><th>Name</th><th>Description</th><th>Price</th><th>Action</th>
  </tr>
  <?php
  $i = 1;
  $res = mysqli_query($conn, "SELECT * FROM products");
  while ($row = mysqli_fetch_assoc($res)):
  ?>
  <tr>
    <td><?= $i++ ?></td>
    <td><img src="images/<?= $row['image'] ?>" width="60"></td>
    <td><?= $row['name'] ?></td>
    <td><?= $row['description'] ?></td>
    <td>RM <?= number_format($row['price'], 2) ?></td>
    <td>
      <a href="manage_food.php?edit=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
      <a href="manage_food.php?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product?')">Delete</a>
    </td>
  </tr>
  <?php endwhile; ?>
</table>

<?php include 'footer.php'; ?>
