<?php
include 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

// Fetch all products
$products = mysqli_query($conn, "SELECT * FROM products");
?>

<h2 class="mb-4">Available Mushrooms</h2>

<div class="row">
<?php while ($row = mysqli_fetch_assoc($products)): ?>
  <div class="col-md-4 mb-4">
    <div class="card h-100 shadow-sm">
      <img src="images/<?= htmlspecialchars($row['image']) ?>" class="card-img-top" style="height: 200px; object-fit: cover;" alt="<?= htmlspecialchars($row['name']) ?>">
      <div class="card-body d-flex flex-column">
        <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
        <p class="card-text"><?= htmlspecialchars($row['description']) ?></p>
        <p class="text-primary fw-bold">RM <?= number_format($row['price'], 2) ?></p>
        <a href="order.php?product_id=<?= $row['id'] ?>" class="btn btn-success mt-auto">Order</a>

        <hr>
        <h6>Leave a Review:</h6>
        <form method="POST" action="review.php">
            <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
            <textarea name="comment" class="form-control mb-2" placeholder="Write a comment..." required></textarea>
            <button type="submit" class="btn btn-sm btn-outline-primary">Post Review</button>
        </form>

        <hr>
        <h6>Recent Reviews:</h6>
        <?php
        $product_id = $row['id'];
        $review_result = mysqli_query($conn, "SELECT r.comment, u.name, r.created_at FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.product_id = $product_id ORDER BY r.created_at DESC LIMIT 3");
        while ($review = mysqli_fetch_assoc($review_result)): ?>
            <p class="small"><strong><?= htmlspecialchars($review['name']) ?>:</strong> <?= htmlspecialchars($review['comment']) ?> <br><em class="text-muted"><?= $review['created_at'] ?></em></p>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
<?php endwhile; ?>
</div>

<?php include 'footer.php'; ?>
