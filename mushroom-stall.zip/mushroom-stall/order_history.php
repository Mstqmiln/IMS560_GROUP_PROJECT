<?php
include 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "SELECT o.id AS order_id, o.total_price, o.status, o.created_at,
                 oi.quantity, p.name AS product_name, p.image
          FROM orders o
          JOIN order_items oi ON o.id = oi.order_id
          JOIN products p ON oi.product_id = p.id
          WHERE o.user_id = ?
          ORDER BY o.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container mt-4">
  <h2>Your Order History</h2>

  <?php if ($result->num_rows > 0): ?>
    <div class="table-responsive mt-3">
      <table class="table table-bordered align-middle">
        <thead class="table-dark">
          <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Qty</th>
            <th>Total (RM)</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><img src="images/<?= htmlspecialchars($row['image']) ?>" width="70" height="70" style="object-fit: cover;"></td>
              <td><?= htmlspecialchars($row['product_name']) ?></td>
              <td><?= $row['quantity'] ?></td>
              <td><?= number_format($row['total_price'], 2) ?></td>
              <td>
                <?php if ($row['status'] == 'pending'): ?>
                  <span class="badge bg-warning text-dark">Pending</span>
                <?php else: ?>
                  <span class="badge bg-success">Success</span>
                <?php endif; ?>
              </td>
              <td><?= $row['created_at'] ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="alert alert-info mt-4">You have no order history yet.</div>
  <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
